import * as wasm from "./addition_bg.wasm";
export * from "./addition_bg.js";