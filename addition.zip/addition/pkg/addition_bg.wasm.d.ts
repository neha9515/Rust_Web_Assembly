/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function add(a: number, b: number): number;
