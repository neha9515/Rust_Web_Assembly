import * as wasm from "./add_wasm_bg.wasm";
export * from "./add_wasm_bg.js";