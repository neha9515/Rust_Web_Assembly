/* tslint:disable */
/* eslint-disable */
/**
* @param {number} n1
* @param {number} n2
* @returns {number}
*/
export function add(n1: number, n2: number): number;
